//---------------------------------------------------------------------------

#ifndef testeH
#define testeH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TFile1Form : public TForm
{
__published:	// IDE-managed Components
private:	// User declarations
public:		// User declarations
        __fastcall TFile1Form(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFile1Form *File1Form;
//---------------------------------------------------------------------------
#endif
