

                Netica API Programmer's Library, version 2.15
                ---------------------------------------------

       Dynamic Link Library (DLL) for Microsoft Windows (95/NT4 to XP)


FILES INCLUDED
--------------

To install, expand the .zip file downloaded from the website or copied
from the disk sent to you, and put them in the hard disk directory of 
your choice (C:\Netica\API\ is a possibility).

After unzipping, you should have a new directory with the 
following files in it:

Netica.dll ---------------- The Netica library (binary file)
Netica.lib ---------------- For the linker to link Netica.dll
Netica.h ------------------ Header file for Netica API
NeticaEx.c ---------------- Extra C source code for Netica API
NeticaEx.h ---------------- Header file for NeticaEx.c
Demo.c -------------------- Source code to try Netica API
Demo.dsw ------------------ Example project for Demo.c
Demo.dsp ------------------ For use by Demo.dsw
LicAgree.txt -------------- License agreement
README.txt ---------------- This file


LICENSE AGREEMENT
-----------------

Before using Netica, make sure you accept the license agreement,
which is included with this package.  If not, return Netica unused 
for a refund.


DEMO PROJECT
------------

It is best to first get the example project working.
Start Visual C++ 5.xx or later, and choose Open Workspace from the File 
menu.  Open "Demo.dsw" (from the unzipping above).

If you have an earlier version of Visual C++, or a different compiler,
or are programming in Visual Basic, Delphi, Pascal, etc., then you should
use Netica.dll in the manner prescribed by those development environments
(standard for a dll), but you will not be able to build the Demo project
as described below.

If you have trouble building Demo.exe in the next step, it may be
because Visual C++ is looking for the source files in the wrong directory.
Simply remove the 6 files from the project (by selecting them when the
FileView tab is active, and pressing Del), and re-add them by choosing
Project -> Add to Project -> Files.  The files necessary to add are:
Demo.c, Netica.dll, NeticaEx.c, Netica.lib.

Choose "Build Demo.exe" from the Build menu, and check that everything
compiles and links without errors, as it constructs your executable
Demo.exe.  Then try running it by choosing Build -> Start Debug -> Go.
If it displays the welcome message, and does some simple probabilistic
inference without any errors, then your installation was probably successful.


LICENSE PASSWORD
----------------

If you have a license password, the next step is to make sure it works.
In Demo.c, change the line that says:

    env = NewNeticaEnviron_bn (NULL);

to one that says:

    env = NewNeticaEnviron_bn ("xxx");

where xxx is the license password provided to you by email, on your shipped 
CD-ROM, or on your invoice.  Then recompile, relink and run it again.
If you get the same message as before (except without the "Netica operating 
without a password ..." line), then your password is working properly.


YOUR PROJECTS
-------------

Once you have the example program running, you can duplicate the "Demo"
project, replace Demo.c with your own source files, and you are ready to 
build your own application.

Alternately, you can simply include Netica.dll and Netica.lib in an existing
project.  If you suspect that any of your project's compiler or linker 
options are incompatible with Netica, you can check to see if they are 
different from the options in the Demo project.  Demo is a console 
application, but of course Netica.dll will work in other types of Windows 
applications as well.

Whenever you run an application which requires Netica dll, Windows must be
  able to find it in one of the following directories:
  1. The directory where the executable module is located.
  2. The current directory.
  3. The Windows system directory ('GetSystemDirectory' function retrieves
     the path of this directory). 
  4. The Windows directory (the 'GetWindowsDirectory' function retrieves 
     the path of this directory).
  5. The directories listed in the PATH environment variable. 


MANUAL and ONSCREEN HELP
------------------------

To use the Netica API, you will need the reference manual.  If the CD-ROM
was shipped to you, then the manual will be included with it.
Otherwise, you can download the manual as a postscript file from the Norsys 
web site.  It is okay if the manual has an earlier version number.

Also, be sure to download and try the online HTML function reference 
for Netica C API, available from the Norsys website and on 
Netica API CD-ROMs.  It is the most useful tool for working with the
C version of Netica API.


PROGRAMMING LANGUAGES
---------------------

Netica API is available for programming in Java, Visual Basic, C and C++.
For more information on Netica API for different languages, see the
Norsys web site.


FUTURE VERSIONS
---------------

Your purchase price includes all version 2.xx releases of Netica (for your
chosen operating system), so your license password will work on all of them.  
They may be downloaded from the Norsys web site.


SPECIAL BUILDS
--------------

Versions of the Netica API library built with different options,
or for different compilers or operating systems, may be purchased from 
Norsys.  Contact Norsys with your request.


PROBLEMS
--------

If you have problems, contact Norsys at:    support@norsys.com


Norsys Software Corp.
www.norsys.com











