
        README.TXT for Netica Application 1.12         Aug. 28, 1998
        --------------------------------------


LICENSE AGREEMENT
-----------------

Before using Netica, make sure you accept the license agreement,
which is included with this package.  If not, return Netica 
unused for a refund.


INSTALLATION
------------

This program requires Windows 95, 98 or NT 4.0.
Installation consumes less than 1 MB of free hard disk space.

Copy Netica_Win.exe to your hard drive and double-click on it.

You can move the resulting Netica folder to wherever you want on your 
hard drive, or rename it, at any time.

Double-click on Netica.exe (within the Netica folder) to run it.  
If you obtained a license password from Norsys by email or on your invoice,
you may enter it at this time.

To uninstall Netica, just delete the above files/folders.  Netica does not 
add any other files anywhere in your system (except of course .dne or .cas 
documents that you save).



NEW SINCE VERSION 1.06
----------------------

  - Decision networks can now have multiple utility nodes, dont need 
      no-forgetting links, can be compiled, can have findings directly 
	  entered, display utility of each decision, etc.
  - There is a "Report" menu, which can generate text reports on:
	  overall network, CPTs, exact node beliefs and findings, list of selected 
	  nodes, junction tree, elimination order
  - Simulate-cases can now use the junction tree if the network is compiled, 
      which does fast, foolproof simulation with no rejection
  - Can zoom in and out with visual display
  - Search/find for node names, titles, states & comments
  - Each node can have its own font and size
  - Text can be displayed on the network diagram, for titles, notes, etc.
  - There is an editable documentation window for the whole network
  - Can make hot links to send beliefs to Excel
  - "Get Case..." now allows reading any case of a multi-case file
  - If you hold down Shift key when choosing "Select All", it inverts selection
  - Now you can do many more levels of 'undo' if the operations dont consume 
      much memory
  - Test Using Cases now reports "test sensitivity", and for binary nodes also 
      test specificity, predictive value and predictive value negative.
	  There is an easy way to create ROC reports.
  - There is a new command to select the nodes listed in text in the clipboard
  - "Optimize-Decisions" now prints expected utility to Messages window
  - "Assume Nodes" are now called "Constant Nodes", and are more useful
  - Simulate-cases now takes likelihood findings into account
  - Saves printer settings of a network diagram in its file
  - Ctrl + drag nodes now duplicates nodes (replaces Edit->Duplicate from menu)
  - Now always displays the hourglass when busy
  - Text editor find/replace now beeps and wraps around if not found.  
      "Replace All" replaces all (even those above cursor).
  - Can now Ctrl-click to extend selection as well as Shift-click
  - Fixed bug: Sometimes selected nodes werent hilited
  - When entering a finding by dialog box, it now shows existing findings 
      (which makes possible just observing what the finding is)
  - Allowed refering to states by just their number in case files, but only 
      for nodes that are not CONTINUOUS and have no state values defined
  - Fixed bug: On some makes of computers, left-clicking on a node was 
      interpreted as a right-click (resulting in the popup menu instead of 
	  selecting the node)
  - Fixed bug: when drawing belief bars, sometimes std. dev. came out 
      infinitesimally negative, resulting in an internal error
  - Fixed Bug: Properly uses paper size from Printer Setup dialog box
  - Changed argument order of HyperGeometricDist function in equations
  - Fixed Bug: In equations, BetaDist with a or b < 1 crashed (also fixed 
      similar problem in beta and loggamma functions)
  - Fixed other minor bugs


NEW SINCE VERSION 1.05a
-----------------------

  - Now has onscreen help and documentation
  - Major improvements to equation feature
  - Utility-free sensitivity analysis
  - Added "Test Net With Cases" feature for scoring the predictive or
    diagnostic accuracy of a belief net
  - Has new layout commands:  Snap To Grid, Align and Equispace
  - Many minor bug fixes and improvements
  - Added standard deviation to belief-bar display of nodes with levels
  - Belief-bar display now normalizes bar lengths (changes scale) if they
    are all very short
  - Fixed bug where focus would sometimes switch to another application
    after dismissing node properties dialog box


FUTURE VERSIONS
---------------

If you have purchased Netica, then your purchase price includes 
all version 1.xx releases of Netica Application (by Internet download), 
so your license password will work on all of them.  
A new release is issued about every 4 months.


PROBLEMS
--------

If you have any problems, send email to:   boerlage@norsys.com
or contact us through our web site at:     www.norsys.com


Norsys Software Corp.
2315 Dunbar St.
Vancouver, BC, Canada
V6R 3N1

===============================================================================


