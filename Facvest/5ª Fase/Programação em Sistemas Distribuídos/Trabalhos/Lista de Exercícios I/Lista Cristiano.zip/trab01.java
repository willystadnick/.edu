public class trab01{
	public static void main(String args[]){
		System.out.println("Retangulo");
		System.out.println("*****");
		System.out.println("*   *");
		System.out.println("*****");
		System.out.println();
		System.out.println("Oval");
		System.out.println(" *** ");
		System.out.println("*   *");
		System.out.println("*   *");
		System.out.println(" *** ");
		System.out.println();
		System.out.println("Seta");
		System.out.println("  *  ");
		System.out.println("   * ");
		System.out.println("*****");
		System.out.println("   * ");
		System.out.println("  *  ");
		System.out.println();
		System.out.println("Losango");
		System.out.println("  *  ");
		System.out.println(" * * ");
		System.out.println("*   *");
		System.out.println(" * * ");
		System.out.println("  *  ");
		System.out.println();
   }
}